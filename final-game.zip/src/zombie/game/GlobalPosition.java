package zombie.game;

/**
 * Super class used to 
 *
 */
public class GlobalPosition {
	
	protected int x;
	protected int y;
	
	public GlobalPosition(int x, int y) {
		this.x = x;
		this.y = y;
	}

}
