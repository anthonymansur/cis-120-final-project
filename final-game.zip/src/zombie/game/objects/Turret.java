package zombie.game.objects;

/*
 * This class is unimplemented as turret will not be 
 * included in this version of game 
 */

public class Turret {

}
